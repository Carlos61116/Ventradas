$(document).ready(function() {
    $(".showpass").on('click', function(event) {
        if($('#pass').attr("type") == "text"){
            $('#pass').attr('type', 'password');
            $('.showpass i').removeClass("far fa-eye-slash");
            $('.showpass i').addClass("far fa-eye");
        }else if($('#pass').attr("type") == "password"){
            $('#pass').attr('type', 'text');
            $('.showpass i').removeClass("far fa-eye" );
            $('.showpass i').addClass("far fa-eye-slash");
           
        }
    });
});