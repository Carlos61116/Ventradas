package com.proyect.main.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyect.main.modelo.Buy;
import com.proyect.main.modelo.Ticket;
import com.proyect.main.modelo.User;

@Service
public class BuyServiceImpl implements BuyService {

	@Autowired
	BuyDAO dao;

	@Override
	public ArrayList<Buy> findAll() {
		return (ArrayList<Buy>) dao.findAll();
	}
	
	@Override
	public Buy saveAndFlush(Buy buy) {
		return dao.saveAndFlush(buy);
	}
	
	@Override
	public Buy save(Buy buy) {
		return dao.save(buy);
	}

	@Override
	public List<Buy> findByUser(User us) {
		return dao.findByUser(us);
	}

	@Override
	public Buy findByidBuy(int id) {
		return dao.findByidBuy(id);
		
	}

	@Override
	public void delete(Buy b) {
		dao.delete(b);
		
	}

	@Override
	public long countBytickets(Ticket t) {
		return dao.countBytickets(t);
	}
	
}
