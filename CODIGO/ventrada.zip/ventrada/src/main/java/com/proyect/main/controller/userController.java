package com.proyect.main.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.proyect.main.modelo.Buy;
import com.proyect.main.modelo.User;
import com.proyect.main.services.BuyServiceImpl;
import com.proyect.main.services.UserServiceImpl;

@Controller
@SessionAttributes("user")
public class userController {
	
	@Autowired
	UserServiceImpl userService;
	
	@Autowired
	BuyServiceImpl buyService;
	
	@GetMapping(value = "admin/userList/{page}")
	public ModelAndView listUser(@PathVariable("page") int page,Model mod) {
		User us =(User) mod.asMap().get("user");
		ModelAndView modelAndView = null;
		if(us.getUsername().equals("admin")) {
			modelAndView = new ModelAndView("admin/userList");
	        PageRequest pageable = PageRequest.of(page - 1, 20);
	        Page<User> allUser = userService.findAll(pageable);
	        int totalPages = allUser.getTotalPages();
	        if(totalPages > 0) {
	            ArrayList<Integer> pageNumbers = (ArrayList<Integer>) IntStream.rangeClosed(1,totalPages).boxed().collect(Collectors.toList());
	            modelAndView.addObject("pageNumbers", pageNumbers);
	        }
	        modelAndView.addObject("activeUserList", true);
	        modelAndView.addObject("users", allUser.getContent());
	        System.out.println(" USUARIOOOOOOOS ------->" + allUser.getContent());
			} else {
				  modelAndView = new ModelAndView("index.html");
			}
        
		return modelAndView;
	}
	
	@RequestMapping(value = "/admin/userList/{page}", method = RequestMethod.GET, params = { "reject" })
	public String deleteOneTicket(@PathVariable("page") int page, @RequestParam(value = "reject") int ticket, Model mod) {
		User us = userService.findByiduser(ticket);
		deleteTicketFromUser(us.getBuys(),us);
		userService.delete(userService.findByiduser(ticket));
		return "redirect:/admin/userList/"+page;
	}
	
	public void deleteTicketFromUser(List<Buy> list,User us) {
		for(Buy buy : list) {
			buyService.delete(buy);
		}
	}

}
