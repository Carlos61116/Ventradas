package com.proyect.main.controller;


import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.proyect.main.modelo.Buy;
import com.proyect.main.modelo.User;
import com.proyect.main.services.BuyServiceImpl;

@Controller
@SessionAttributes("user")
public class mainController {
	
	@Autowired
	private BuyServiceImpl buyService;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)	
	public String showIndex(Model model) {
		System.out.println("Inicio");
		if(!model.containsAttribute("user")) {
			model.addAttribute("user",new User());
		}
		return "index";
	}
	
	@RequestMapping(value = "/home", method = RequestMethod.GET)	
	public String showHome(@ModelAttribute(name="user") User user,Model model) {
		System.out.println("IdUser ->"+user.getIduser());
		return "home";
	}
	
	@RequestMapping(value = "/home", method = RequestMethod.GET , params={"compra"})	
	public String showHomeAfterBuy(@ModelAttribute(name="user") User user,@RequestParam(value = "compra", required=false) final String compra, Model model) {
		if(compra.equals("successs")) {
			model.addAttribute("compra","La compra se ha realizado con éxito");
		} else {
			model.addAttribute("compra","Error en la compra");
		}
		System.out.println("IdUser ->"+user.getIduser());
		return "home";
	}
	
	@GetMapping(value = "/ticket/{idBuy}")
	@ResponseBody
    public String showQR(@PathVariable  int idBuy,Model mod) throws IOException {
        Buy buyToShow = buyService.findByidBuy(idBuy);
        System.out.println(buyToShow);
        String info = buyToShow.getUser().getFirstName() + " " + buyToShow.getUser().getLastName() +" \n "+ buyToShow.getIdBuy() + " \n" + buyToShow.getTickets().getConcert().getConcertName() + " \n "+ buyToShow.getTickets().getConcert().getDate();
        return info;
    } 
	
	
	

}
