package com.proyect.main.services;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.proyect.main.modelo.User;

@Service
@SuppressWarnings("unchecked")
public interface UserDao extends JpaRepository<User, Integer> {
    User findByUsernameAndPassword(String username,String password);
    User saveAndFlush(User u);
    User findByUsername(String username);
    long count();
    void flush();
    void delete(User u);
    User findByiduser(int usr);
}