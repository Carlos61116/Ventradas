package com.proyect.main.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ErrorController {
	
	@GetMapping({"/error"})
	public String viewError() {
		System.out.println("Error en redireccion");
		return "error";
	}

}
