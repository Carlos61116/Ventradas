package com.proyect.main.services;

import java.util.ArrayList;

import com.proyect.main.modelo.Band;

public interface BandService {
	ArrayList<Band> findAll();
	public Band findByBandName(String bandName);
	public Band save(Band band);

}
