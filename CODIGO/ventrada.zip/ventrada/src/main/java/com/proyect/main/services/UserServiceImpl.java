package com.proyect.main.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.proyect.main.modelo.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao dao;
	

	@Override
	public User findByUsernameAndPassword(String nombre,String password) {
		return dao.findByUsernameAndPassword(nombre,password);
	}


	@Override
	public User saveAndFlush(User us) {
		return dao.saveAndFlush(us);
	}


	@Override
	public Long count() {
		return dao.count();
	}


	@Override
	public void flush() {
		dao.flush();
		
	}


	@Override
	public User findByUsername(String username) {
		return dao.findByUsername(username);
	}


	
	public Page<User> findAll(Pageable pageable) {
		return dao.findAll(pageable);
	}


	@Override
	public void delete(User u) {
		dao.delete(u);
		
	}


	@Override
	public User findByiduser(int usr) {
		return dao.findByiduser(usr);
	}
}
