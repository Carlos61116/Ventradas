package com.proyect.main.services;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.proyect.main.modelo.Band;


@Service
public interface BandDAO extends JpaRepository<Band, Integer> {
	public List<Band> findAll();
	public Band findByBandName(String bandName);
	@SuppressWarnings("unchecked")
	public Band save(Band band);
}
