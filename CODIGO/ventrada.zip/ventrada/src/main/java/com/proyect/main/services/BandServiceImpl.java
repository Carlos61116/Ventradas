package com.proyect.main.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyect.main.modelo.Band;

@Service
public class BandServiceImpl implements BandService {

	@Autowired
	BandDAO dao;

	@Override
	public ArrayList<Band> findAll() {
		return (ArrayList<Band>) dao.findAll();
	}

	@Override
	public Band findByBandName(String bandName) {
		// TODO Auto-generated method stub
		return dao.findByBandName(bandName);
	}

	@Override
	public Band save(Band band) {
		return dao.save(band);
	}
	

	
}
