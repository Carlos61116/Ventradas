package com.proyect.main.services;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.proyect.main.modelo.Band;
import com.proyect.main.modelo.Concert;


@Service
@SuppressWarnings("unchecked")
public interface ConcertDAO extends JpaRepository<Concert, Integer> {
	public List<Concert> findAllByOrderByDateDesc();
	public Concert findByidConcert(int ID);
	public List<Concert> findByCityOrderByDate(String city);
	public List<Concert> findByBandOrderByDate(Band band);
	public Concert saveAndFlush(Concert t);
	public Concert findTopByOrderByIdConcertDesc();

}
