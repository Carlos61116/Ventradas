package com.proyect.main.services;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.proyect.main.modelo.Concert;
import com.proyect.main.modelo.Ticket;


@Service
@SuppressWarnings("unchecked")
public interface TicketDAO extends JpaRepository<Ticket, Integer> {
	public List<Ticket> findAll();
	public Ticket saveAndFlush(Ticket tq);
	public Ticket findFirstTicketDistinctByConcert(Concert t);
	public Ticket findByConcert(Concert ct);
}
