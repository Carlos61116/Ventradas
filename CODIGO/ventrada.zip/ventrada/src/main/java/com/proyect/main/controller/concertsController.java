package com.proyect.main.controller;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.proyect.main.modelo.Buy;
import com.proyect.main.modelo.Concert;
import com.proyect.main.modelo.Ticket;
import com.proyect.main.modelo.User;
import com.proyect.main.services.BandServiceImpl;
import com.proyect.main.services.BuyServiceImpl;
import com.proyect.main.services.ConcertServiceImpl;
import com.proyect.main.services.TicketServiceImpl;

@Controller
@SessionAttributes("user")
public class concertsController {

	@Autowired
	private ConcertServiceImpl concertService;

	@Autowired
	private BuyServiceImpl buyService;

	@Autowired
	private TicketServiceImpl ticketService;

	@Autowired
	private BandServiceImpl bandService;

	@RequestMapping(value = "/concerts/list", method = RequestMethod.GET)
	public String viewConcerts(Model mod) {
		mod.addAttribute("concert", concertService.findAllByOrderByDateDesc());
		return "concerts/list";
	}

	@GetMapping({ "concerts/{bandIdband}" })
	public String viewBuy(@PathVariable int bandIdband, Model mod) {
		System.out.println("ID: " + bandIdband);
		Concert concert = concertService.findByidConcert(bandIdband);
		mod.addAttribute("tickets", buyService.countBytickets(concert.getTickets()));
		mod.addAttribute("concert", concert);
		return "concerts/buy";
	}

	@RequestMapping(value = "concerts/{id}", method = RequestMethod.GET, params = { "id" })
	public ModelAndView buy(@PathVariable int id, Model mod, ModelAndView moVi) {
		System.out.println("Compra del concierto: " + id);
		User usuarioActivo = (User) mod.asMap().get("user");
		Concert ct = concertService.findByidConcert(id);
		Ticket ticketActual = ticketService.findFirstTicketDistinctByConcert(ct);
		System.out.println("Nombre del concierto: " + ticketActual.getConcert().getConcertName());
		Buy nuevaCompra = new Buy();

		nuevaCompra.setUser(usuarioActivo);
		nuevaCompra.setTickets(ticketActual);

		buyService.saveAndFlush(nuevaCompra);

		if (mod != null) {
			// Ha dado true por lo que se ha realizado la compra
			moVi.addObject("compra", "success");
			moVi.setViewName("redirect:/home");

		}
		return moVi;
	}

	@RequestMapping(value = "/concerts/list", method = RequestMethod.GET, params = { "city" })
	public String showByCity(@RequestParam String city, Model mod) {
		System.out.println("City -> " + city);
		ArrayList<Concert> conciertos = (ArrayList<Concert>) concertService.findByCityOrderByDate(city);
		mod.addAttribute("concert", conciertos);
		if (conciertos.isEmpty())
			mod.addAttribute("vacio", "No existen conciertos en tu ciudad");
		return "concerts/list";
	}

	@RequestMapping(value = "/concerts/list", method = RequestMethod.GET, params = { "band" })
	public String showByBand(@RequestParam String band, Model mod) {
		System.out.println("Band -> " + band);
		ArrayList<Concert> conciertos = (ArrayList<Concert>) concertService
				.findByBandOrderByDate(bandService.findByBandName(band));
		mod.addAttribute("concert", conciertos);
		if (conciertos.isEmpty())
			mod.addAttribute("vacio", "No existen conciertos de tu banda favorita");
		return "concerts/list";
	}

	@RequestMapping(value = "/admin/concert", method = RequestMethod.GET)
	public String showCreateConcert(Model mod) {
		User us = (User) mod.asMap().get("user");
		String src = null;
		if (us.getUsername().equals("admin")) {
			mod.addAttribute("bands", bandService.findAll());
		} else {
			src = "index.html";
		}
		return src;
	}

	@RequestMapping(value = "/admin/concert", method = RequestMethod.POST)
	public String createConcert(@ModelAttribute(name = "loginForm") Concert concert,
			@RequestParam(name = "ticketPrice") int precio, Model mod) {
		User us = (User) mod.asMap().get("user");
		String src = null;
		if (us.getUsername().equals("admin")) {
			src = "redirect:/admin/concert";
			if (concert.getSrc() == "") {
				concert.setSrc("https://i.imgur.com/ivF4Icn.png");
			}
			concertService.saveAndFlush(concert);
			Concert newConcert = concertService.findTopByOrderByIdConcertDesc();
			Ticket tq = new Ticket();
			tq.setPrice(precio);
			tq.setConcert(newConcert);
			ticketService.saveAndFlush(tq);
			newConcert.setTickets(tq);
		} else {
			src = "index.html";
		}
		return src;
	}

}
