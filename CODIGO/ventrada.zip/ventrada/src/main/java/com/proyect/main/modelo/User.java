package com.proyect.main.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;


/**
 * The persistent class for the user database table.
 * 
 */
@Entity
@NamedQuery(name="User.findAll", query="SELECT u FROM User u")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int iduser;

	private String city;

	@Column(name="favorite_band")
	private String favoriteBand;

	@Column(name="first_name")
	private String firstName;

	@Column(name="last_name")
	private String lastName;

	private String password;

	private String username;

	//bi-directional many-to-one association to Buy
	@OneToMany(fetch = FetchType.EAGER, mappedBy="user" )
	private List<Buy> buys;

	public User() {
	}

	public int getIduser() {
		return this.iduser;
	}

	public void setIduser(int iduser) {
		this.iduser = iduser;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getFavoriteBand() {
		return this.favoriteBand;
	}

	public void setFavoriteBand(String favoriteBand) {
		this.favoriteBand = favoriteBand;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<Buy> getBuys() {
		return this.buys;
	}

	public void setBuys(List<Buy> buys) {
		this.buys = buys;
	}

	public Buy addBuy(Buy buy) {
		getBuys().add(buy);
		buy.setUser(this);

		return buy;
	}

	public Buy removeBuy(Buy buy) {
		getBuys().remove(buy);
		buy.setUser(null);

		return buy;
	}

	@Override
	public String toString() {
		return "User [iduser=" + iduser + ", city=" + city + ", favoriteBand=" + favoriteBand + ", firstName="
				+ firstName + ", lastName=" + lastName + ", password=" + password + ", username=" + username + "]";
	}

}