package com.proyect.main.services;

import java.util.ArrayList;
import java.util.List;

import com.proyect.main.modelo.Buy;
import com.proyect.main.modelo.Ticket;
import com.proyect.main.modelo.User;

public interface BuyService {
	ArrayList<Buy> findAll();
	Buy saveAndFlush(Buy buy);
	Buy save(Buy buy);
	public List<Buy> findByUser(User us);
	public Buy findByidBuy(int id);
	public void delete(Buy b);
	public long countBytickets(Ticket t);

}
