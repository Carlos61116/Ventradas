package com.proyect.main.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.PrimaryKeyJoinColumn;


/**
 * The persistent class for the buy database table.
 * 
 */
@Entity
@NamedQuery(name="Buy.findAll", query="SELECT b FROM Buy b")
public class Buy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_buy")
	private int idBuy;

	//bi-directional many-to-one association to User
	@ManyToOne
	@PrimaryKeyJoinColumn
	private User user;

	//bi-directional many-to-one association to Ticket
	@ManyToOne
	@PrimaryKeyJoinColumn
	private Ticket tickets;

	public Buy() {
	}

	public int getIdBuy() {
		return this.idBuy;
	}

	public void setIdBuy(int idBuy) {
		this.idBuy = idBuy;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public  Ticket getTickets() {
		return this.tickets;
	}

	public void setTickets(Ticket tickets) {
		this.tickets = tickets;
	}
	




}