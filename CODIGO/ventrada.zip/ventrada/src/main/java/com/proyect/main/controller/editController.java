package com.proyect.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.proyect.main.modelo.User;
import com.proyect.main.services.UserServiceImpl;

@Controller
@SessionAttributes("user")
public class editController {
	
	@Autowired
	private UserServiceImpl userService;
	


	@RequestMapping(value = "user/edit", method = RequestMethod.GET)	
	public String viewEdit(Model model) {
		System.out.println("Editar");
		return "user/edit";
	}
	
	@RequestMapping(value = "/user/edit", method = RequestMethod.POST)	
	public String editUser(@ModelAttribute(name="loginForm") User user,Model model) {
		User us = (User) model.asMap().get("user");
		user.setIduser(us.getIduser());
		System.out.println(us);
		User uss = null;
		if((userService.findByUsername(user.getUsername()) == null && !user.getUsername().equals(us.getUsername())) || user.getUsername().equals(us.getUsername())) {
			uss = userService.saveAndFlush(user);
			userService.flush();
			uss = userService.findByUsernameAndPassword(user.getUsername(), user.getPassword()); 
		}
		
		if(uss!=null) {
		model.addAttribute("user",uss);
		model.addAttribute("exito","Se han guardado los cambios correctamente");
			return "user/edit";
		}
		else {
			model.addAttribute("error","Ya existe un usuario con ese nombre");
			return viewEdit(model);
		}
	
	}
	
	/* 
	 * Si cambia el nombre !usernameEqualsUsName y si no existen user==null
	 * Si no cambia
	 *  ------>
	 *  Actualizar 
	 * 
	 * */

}
