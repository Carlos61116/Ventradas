package com.proyect.main.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyect.main.modelo.Band;
import com.proyect.main.modelo.Concert;

@Service
public class ConcertServiceImpl implements ConcertService {

	@Autowired
	ConcertDAO dao;

	@Override
	public ArrayList<Concert> findAllByOrderByDateDesc() {
		return (ArrayList<Concert>) dao.findAllByOrderByDateDesc();
	}

	@Override
	public Concert findByidConcert(int ID) {
		return dao.findByidConcert(ID);
	}

	@Override
	public List<Concert> findByCityOrderByDate(String city) {
		// TODO Auto-generated method stub
		return dao.findByCityOrderByDate(city);
	}

	@Override
	public List<Concert> findByBandOrderByDate(Band band) {
		// TODO Auto-generated method stub
		return dao.findByBandOrderByDate(band);
	}

	@Override
	public Concert saveAndFlush(Concert t) {
		return dao.saveAndFlush(t);
	}

	@Override
	public Concert findTopByOrderByIdConcertDesc() {
		// TODO Auto-generated method stub
		return dao.findTopByOrderByIdConcertDesc();
	}
	

	
}
