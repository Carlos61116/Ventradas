package com.proyect.main.services;

import java.util.ArrayList;

import com.proyect.main.modelo.Concert;
import com.proyect.main.modelo.Ticket;

public interface TicketService {
	ArrayList<Ticket> findAll();
	Ticket saveAndFlush(Ticket tq);
	public Ticket findFirstTicketDistinctByConcert(Concert t);
	public Ticket findByConcert(Concert ct);
}
