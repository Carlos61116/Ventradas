package com.proyect.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.proyect.main.modelo.Band;
import com.proyect.main.modelo.User;
import com.proyect.main.services.BandServiceImpl;

@Controller
@SessionAttributes("user")
public class bandController {
	
 @Autowired
 private BandServiceImpl bandservice;
	 
	
	
	@GetMapping({"/bands/list"})
	public String viewbands(Model model) {
		model.addAttribute("band",bandservice.findAll());
		return "bands/list";
	}
	
	@GetMapping({"/admin/band"})
	public String viewCreateBand(Model model) {
		User us =(User) model.asMap().get("user");
		String src = null;
		if(us.getUsername().equals("admin")) {
			src = "admin/band";
		} else {
			src = "index.html";
		}
		return src;
	}
	
	@PostMapping({"/admin/band"})
	public String createBand(@ModelAttribute(name="loginForm") Band band, Model model) {
		System.out.println(band);
		Band bandaGuardada = bandservice.save(band);
		
		if(bandaGuardada!=null) {
			model.addAttribute("saved","Éxito al crear la banda");
		}
		return "admin/band";
	}

}
