package com.proyect.main.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BarcodeQRCode;
import com.itextpdf.text.pdf.PdfWriter;
import com.proyect.main.modelo.Buy;
import com.proyect.main.modelo.Ticket;
import com.proyect.main.modelo.User;
import com.proyect.main.services.BuyServiceImpl;

@Controller
@SessionAttributes("user")
public class BuyController {

	@Autowired
	private BuyServiceImpl buyService;

	@GetMapping({"/tickets/list"})
	public String showAllTickets(Model mod) {
		User usuarioActivo = (User) mod.asMap().get("user");
		ArrayList<Buy> totalCompras = (ArrayList<Buy>) buyService.findByUser(usuarioActivo);
		mod.addAttribute("buys", totalCompras);
		System.out.println(totalCompras);
		return "tickets/list";
	}

	@RequestMapping(value = "/tickets/list", method = RequestMethod.GET, params = { "reject" })
	public String deleteOneTicket(@RequestParam(value = "reject") int ticket, Model mod) {
		User usuarioActivo = (User) mod.asMap().get("user");
		Buy buyToElimate = buyService.findByidBuy(ticket);
		System.out.println("Compra -> " + buyToElimate);
		buyService.delete(buyToElimate);
		System.out.println(usuarioActivo.getBuys());
		System.out.println("Elimina correctamente! -> " + usuarioActivo.getIduser());
		return "redirect:/tickets/list";
	}

	@GetMapping(value = "/tickets/list", params = { "download" })
	public void showPDF(@RequestParam(value = "download") int ticket, HttpServletResponse response, Model mod)
			throws IOException {
		Buy compraActual = buyService.findByidBuy(ticket);
		Ticket ticketActual = compraActual.getTickets();
		createPDF(mod, compraActual, ticketActual);
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"ticket.pdf\"");
		@SuppressWarnings("resource")
		InputStream inputStream = new FileInputStream(new File("ticket.pdf"));
		int nRead;
		while ((nRead = inputStream.read()) != -1) {
			response.getWriter().write(nRead);
		}
	}

	public void createPDF(Model mod, Buy compraActual, Ticket ticketActual) {
		User usuarioActivo = (User) mod.asMap().get("user");
		try {
			Document document = new Document();
			PdfWriter.getInstance(document, new FileOutputStream("ticket.pdf"))
					.setInitialLeading(20);

			String ipAddress = getIP();

			document.open();

			Font font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLACK);

			BarcodeQRCode my_code = new BarcodeQRCode("http://" + ipAddress + ":8080/ticket/" + compraActual.getIdBuy(),
					400, 300, null);

			Image qr_image = my_code.getImage();

			Image logo = Image.getInstance("logo.png");
			logo.scalePercent(40);
			document.addHeader("ORIGEN", "VENTRADAS");
			document.addTitle("VENTADRAS");
			document.add(new Paragraph("VENTRADAS"));
			document.add(logo);
			document.add(
					new Paragraph("Entrada para el concierto: " + ticketActual.getConcert().getConcertName(), font));
			document.add(new Paragraph(
					"Dueño de la entrada: " + usuarioActivo.getLastName() + ", " + usuarioActivo.getFirstName(), font));
			document.add(qr_image);
			document.add(new Paragraph("Fecha del concierto: " + ticketActual.getConcert().getDate(), font));
			Paragraph footer = new Paragraph(
					"Código entrada: " + compraActual.getIdBuy() + "" + (int) Math.floor(Math.random() + 10 * 20),
					font);
			footer.setAlignment(Paragraph.ALIGN_BOTTOM);
			document.add(footer);
			document.close();

		} catch (Exception ne) {
			System.err.println(ne);
		}
	}

	public String getIP() {
		String ip = null;
		try {
			final DatagramSocket socket = new DatagramSocket();
			socket.connect(InetAddress.getByName("8.8.8.8"), 10002);
			 ip = socket.getLocalAddress().getHostAddress();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ip;
	}

}
