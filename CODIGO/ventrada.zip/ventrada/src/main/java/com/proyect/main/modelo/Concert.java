package com.proyect.main.modelo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;


/**
 * The persistent class for the concert database table.
 * 
 */
@Entity
@NamedQuery(name="Concert.findAll", query="SELECT c FROM Concert c")
public class Concert implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_concert")
	private int idConcert;

	@Column(name="amount_tickets")
	private int amountTickets;

	private String city;
	
	private String src;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date date;

	public String getSrc() {
		return src;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setSrc(String src) {
		this.src = src;
	}

	@Column(name="concert_name")
	private String concertName;

	//bi-directional many-to-one association to Band
	@ManyToOne
	@JoinColumn(name="id_band")
	private Band band;

	//bi-directional many-to-one association to Ticket
	@OneToOne(mappedBy="concert")
	private Ticket tickets;

	public Concert() {
	}

	public int getIdConcert() {
		return this.idConcert;
	}

	public void setIdConcert(int idConcert) {
		this.idConcert = idConcert;
	}

	public int getAmountTickets() {
		return this.amountTickets;
	}

	public void setAmountTickets(int amountTickets) {
		this.amountTickets = amountTickets;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getConcertName() {
		return this.concertName;
	}

	public void setConcertName(String concertName) {
		this.concertName = concertName;
	}

	public Band getBand() {
		return this.band;
	}

	public void setBand(Band band) {
		this.band = band;
	}

	public Ticket getTickets() {
		return this.tickets;
	}

	public void setTickets(Ticket tickets) {
		this.tickets = tickets;
	}

	
	
	@Override
	public String toString() {
		return "Concert [idConcert=" + idConcert + ", amountTickets=" + amountTickets + ", city=" + city + ", src="
				+ src + ", date=" + date + ", concertName=" + concertName + ", band=" + band + "]";
	}


}