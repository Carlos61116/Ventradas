package com.proyect.main.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyect.main.modelo.Concert;
import com.proyect.main.modelo.Ticket;

@Service
public class TicketServiceImpl implements TicketService {

	@Autowired
	TicketDAO dao;

	@Override
	public ArrayList<Ticket> findAll() {
		return (ArrayList<Ticket>) dao.findAll();
	}
	
	@Override
	public Ticket saveAndFlush(Ticket tq) {
		return dao.save(tq);
	}

	@Override
	public Ticket findFirstTicketDistinctByConcert(Concert t) {
		return dao.findFirstTicketDistinctByConcert(t);
	}

	@Override
	public Ticket findByConcert(Concert ct) {
		return dao.findByConcert(ct);
	}
	

	
}
