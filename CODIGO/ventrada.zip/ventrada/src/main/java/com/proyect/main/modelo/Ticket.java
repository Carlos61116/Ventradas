package com.proyect.main.modelo;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * The persistent class for the tickets database table.
 * 
 */
@Entity
@Table(name="tickets")
@NamedQuery(name="Ticket.findAll", query="SELECT t FROM Ticket t")
public class Ticket implements Serializable {
	@Override
	public String toString() {
		return "Ticket [idtickets=" + idtickets + ", price=" + price + ", concert=" + concert + "]";
	}

	private static final long serialVersionUID = 1L;

	@Id
	private int idtickets;

	private int price;

	//bi-directional many-to-one association to Concert
	@OneToOne
	@JoinColumn(name="band_id")
	private Concert concert;



	public Ticket() {
	}

	public int getIdtickets() {
		return this.idtickets;
	}

	public void setIdtickets(int idtickets) {
		this.idtickets = idtickets;
	}

	public int getPrice() {
		return this.price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Concert getConcert() {
		return this.concert;
	}

	public void setConcert(Concert concert) {
		this.concert = concert;
	}

}