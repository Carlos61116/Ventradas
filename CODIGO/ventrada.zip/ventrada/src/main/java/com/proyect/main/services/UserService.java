package com.proyect.main.services;

import com.proyect.main.modelo.User;

public interface UserService {
	User findByUsernameAndPassword(String nombre,String password);
	User saveAndFlush(User us);
	Long count();
	void flush();
	User findByUsername(String username);
	void delete(User u);
    User findByiduser(int usr);

}
