package com.proyect.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.proyect.main.modelo.User;
import com.proyect.main.services.UserServiceImpl;


@Controller
@SessionAttributes("user")
public class registerController {

	@Autowired
	private UserServiceImpl userService;
	


	@RequestMapping(value = "/user/register", method = RequestMethod.GET)	
	public String viewLogin(Model model) {
		System.out.println("Register");
		return "user/register";
	}
	
	@RequestMapping(value = "/user/register", method = RequestMethod.POST)	
	public String login(@ModelAttribute(name="loginForm") User user,Model model) {
		String red = "";
		if(userService.findByUsername(user.getUsername()) == null) {
			User uss = userService.saveAndFlush(user);
			uss = userService.findByUsernameAndPassword(user.getUsername(), user.getPassword()); 
			if(uss!=null) {
				model.addAttribute("user",uss);
				red = "redirect:/home";
			} else {
				model.addAttribute("error","Error al insertar");
				red = "user/register";
			}
			
		} else {
			model.addAttribute("error","Ya existe un usuario con ese nombre");
			red = "user/register";
		}
		
			
		return red;
	
	
	}

}
