package com.proyect.main.modelo;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the band database table.
 * 
 */
@Entity
@NamedQuery(name="Band.findAll", query="SELECT b FROM Band b")
public class Band implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int idband;

	@Column(name="band_name")
	private String bandName;

	private String components;

	private String description;

	private String genre;

	//bi-directional many-to-one association to Concert
	@OneToMany(mappedBy="band")
	private List<Concert> concerts;

	@Override
	public String toString() {
		return "Band [idband=" + idband + ", bandName=" + bandName + ", components=" + components + ", description="
				+ description + ", genre=" + genre + "]";
	}

	public Band() {
	}

	public int getIdband() {
		return this.idband;
	}

	public void setIdband(int idband) {
		this.idband = idband;
	}

	public String getBandName() {
		return this.bandName;
	}

	public void setBandName(String bandName) {
		this.bandName = bandName;
	}

	public String getComponents() {
		return this.components;
	}

	public void setComponents(String components) {
		this.components = components;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getGenre() {
		return this.genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public List<Concert> getConcerts() {
		return this.concerts;
	}

	public void setConcerts(List<Concert> concerts) {
		this.concerts = concerts;
	}

	public Concert addConcert(Concert concert) {
		getConcerts().add(concert);
		concert.setBand(this);

		return concert;
	}

	public Concert removeConcert(Concert concert) {
		getConcerts().remove(concert);
		concert.setBand(null);

		return concert;
	}

}