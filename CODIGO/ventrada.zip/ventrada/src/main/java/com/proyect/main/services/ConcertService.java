package com.proyect.main.services;

import java.util.ArrayList;
import java.util.List;

import com.proyect.main.modelo.Band;
import com.proyect.main.modelo.Concert;

public interface ConcertService {
	ArrayList<Concert> findAllByOrderByDateDesc();
	Concert findByidConcert(int ID);
	public List<Concert> findByCityOrderByDate(String city);
	public List<Concert> findByBandOrderByDate(Band band);
	public Concert saveAndFlush(Concert t);
	public Concert findTopByOrderByIdConcertDesc();

}
