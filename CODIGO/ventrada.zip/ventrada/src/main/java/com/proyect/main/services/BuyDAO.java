package com.proyect.main.services;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.proyect.main.modelo.Buy;
import com.proyect.main.modelo.Ticket;
import com.proyect.main.modelo.User;


@Service
@SuppressWarnings("unchecked")
public interface BuyDAO extends JpaRepository<Buy, Integer> {
	public List<Buy> findAll();
	public Buy saveAndFlush(Buy buy);
	public Buy save(Buy buy);
	public List<Buy> findByUser(User us);
	public Buy findByidBuy(int id);
	public void delete(Buy b);
	public long countBytickets(Ticket t);

}
