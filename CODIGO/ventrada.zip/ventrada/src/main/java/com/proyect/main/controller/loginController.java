package com.proyect.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.proyect.main.modelo.User;
import com.proyect.main.services.UserServiceImpl;


@Controller
@SessionAttributes("user")
public class loginController {

	@Autowired
	private UserServiceImpl userService;
	 
	@RequestMapping(value = "/user/login", method = RequestMethod.GET)	
	public String logInt( Model model) {
		System.out.println("Login");
		return "user/login";
	}

	@RequestMapping(value = "/user/login", method = RequestMethod.GET, params={"log"})	
	public String logOut(@RequestParam(value = "log", required=false) final String logout, Model model) {
		System.out.println("LogOut");
		if(logout.equals("out")) {
			model.addAttribute("user",new User());
		}
		return "user/login";
	}
	
	@RequestMapping(value = "/user/login", method = RequestMethod.POST)	
	public String login(@ModelAttribute(name="loginForm") User user,Model model) {
		String username = user.getUsername();
		String password = user.getPassword();
		User uss = userService.findByUsernameAndPassword(username,password);
		if(uss!=null) {
		model.addAttribute("user",uss);
			return "redirect:/home";
		}
		else {
			model.addAttribute("error","El usuario o la contraseña son incorrecta");
			return "user/login";
			
		}
	
	}

}
